library(tidyverse)

url = "https://raw.githubusercontent.com/zhaolinli1030/Dataset/main/players_22.csv"
fifa = read_csv(url)

fifa = fifa |> 
  rename(League = `league_name`, Club = `club_name`, Position = `club_position`, Wage = `wage_eur`) |> 
  select(-c(19:110))

write_csv(x = fifa, file = "data/fifa.csv")

fifa |> 
  filter(League == "Spain Primera Division") |> 
  filter(Club == "Real Madrid CF") |> 
  group_by(Position) |> 
  summarise(avg_wage = mean(Wage)) |> 
  ggplot() +
  aes(x = Position, y = avg_wage, fill = Position) |> 
  geom_bar(stat = "identity") + 
  theme_bw() +
  geom_text(aes(x = Position, y = avg_wage, label = avg_wage)) +
  ylab("avg_wage (in EUR)")
