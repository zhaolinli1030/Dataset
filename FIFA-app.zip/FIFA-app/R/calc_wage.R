calc_wage = function(data) {
  a = data |> 
    group_by(Club) |> 
    summarise(Club_Avg_Wage = round(mean(Wage), digits = 0), .groups = "drop") |> 
    select(Club, Club_Avg_Wage)
  data |> 
    left_join(a, by = "Club") |> 
    select(Full_Name = long_name, League, Club, Position, Wage, Club_Avg_Wage) |> 
    mutate(Difference = Wage - Club_Avg_Wage)
}