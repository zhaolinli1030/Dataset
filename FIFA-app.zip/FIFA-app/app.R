library(shiny)
library(tidyverse)

fifa = read_csv(file = "data/fifa.csv")

ui = navbarPage(
  title = "FIFA",
  tabPanel(
    title = "Input / Visualization",
    titlePanel(title = "FIFA 2022 Players Weekly Wage"),
    sidebarLayout(
      sidebarPanel(
        selectInput(
          inputId = "league",
          label = "League:",
          choices = sort(unique(fifa$League)),
          selected = "Spain Primera Division"),
        selectInput(
          inputId = "club",
          label = "Club:",
          choices = sort(unique(fifa$Club))),
        checkboxInput(inputId = "clubname", 
                      label = "Filter Table to Club Name", 
                      value = FALSE)
      ),
      mainPanel(plotOutput("plot"))
    )
  ),
  tabPanel(title = "Table", dataTableOutput("table")),
  tabPanel(title = "About", includeMarkdown("about.Rmd"))
  
)

server = function(input, output) {
  
  fifa_league = reactive({
    fifa |> 
      filter(League == input$league)
  })
  
  observeEvent(
    eventExpr = input$league, 
    handlerExpr = {
      updateSelectInput(inputId = "club", 
                        choices = sort(unique(fifa_league()$Club)),
                        selected = sort(unique(fifa_league()$Club))[1])
    }
  )
  
  output$plot = renderPlot({
    
    fifa |> 
      filter(League == input$league) |> 
      filter(Club == input$club) |> 
      group_by(Position) |> 
      summarise(avg_wage = round(mean(Wage), digits = 0)) |> 
      ggplot() +
      aes(x = Position, y = avg_wage, fill = Position) |> 
      geom_bar(stat = "identity") + 
      theme_bw() +
      geom_text(aes(x = Position, y = avg_wage, label = avg_wage)) +
      ylab("Avg_Wage (in EUR)")
  })
  
  output$table = renderDataTable({
    
    tab = fifa_league() |> 
      calc_wage()
    
    if (input$clubname) {
      tab = tab |> 
        filter(Club == input$club)
    }
    
    tab
  })
  
}

shinyApp(ui = ui, server = server)
